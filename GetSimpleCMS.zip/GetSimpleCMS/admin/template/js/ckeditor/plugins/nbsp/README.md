# nbsp
nbsp plugin for CKEditor
